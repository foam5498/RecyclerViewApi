package com.messanger.kotlin.recyclerviewapi

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.widget.DividerItemDecoration
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.OrientationHelper
import com.androidnetworking.AndroidNetworking
import com.androidnetworking.error.ANError
import com.androidnetworking.interfaces.ParsedRequestListener
import com.messanger.kotlin.recyclerviewapi.model.Actor
import com.messanger.kotlin.recyclerviewapi.model.ReqestUser
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    private val dataList: MutableList<Actor> = mutableListOf()
    private lateinit var myAdapter: MyAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // setup adapter
        myAdapter = MyAdapter(dataList)

        //setup recyclerView
        my_recycler_view.layoutManager = LinearLayoutManager(this)
        my_recycler_view.addItemDecoration(DividerItemDecoration(this, OrientationHelper.VERTICAL))
        my_recycler_view.adapter = myAdapter

        // setup Android Networking
        AndroidNetworking.initialize(this)

        AndroidNetworking.get("https://api.github.com/events")
            .build()
            .getAsObject(ReqestUser::class.java, object  : ParsedRequestListener<ReqestUser> {
                override fun onResponse(response: ReqestUser) {
                    dataList.add(response.actor)
                    myAdapter.notifyDataSetChanged()
                }

                override fun onError(anError: ANError?) {

                }

            })
    }
}
