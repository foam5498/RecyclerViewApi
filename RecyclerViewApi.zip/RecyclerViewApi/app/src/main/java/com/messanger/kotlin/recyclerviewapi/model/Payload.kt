package com.messanger.kotlin.recyclerviewapi.model

import com.google.gson.annotations.SerializedName

data class Payload(
    @SerializedName("before")
    val before: String,
    @SerializedName("commits")
    val commits: List<Any>,
    @SerializedName("distinct_size")
    val distinctSize: Int,
    @SerializedName("head")
    val head: String,
    @SerializedName("push_id")
    val pushId: Long,
    @SerializedName("ref")
    val ref: String,
    @SerializedName("size")
    val size: Int
)