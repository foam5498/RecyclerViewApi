package com.messanger.kotlin.recyclerviewapi

import android.support.v7.widget.RecyclerView
import android.view.View

class MyHolder(itemView: View) : RecyclerView.ViewHolder(itemView)